<template>
  <router-view />
</template>

<script setup lang="ts">
// Vue 3 + script setup 不需要额外逻辑
</script>

<style>
html, body, #app {
  height: 100%;
  margin: 0;
  padding: 0;
  background: #f5f5f5;
}
</style>
